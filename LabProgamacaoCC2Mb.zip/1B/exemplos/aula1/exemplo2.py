print('Informe o valor de A: ')
a = int(input())
print('Informe o valor de B: ')
b = int(input())

if a > b:
  print('Mensagem 1')
print('Mensagem 2') 