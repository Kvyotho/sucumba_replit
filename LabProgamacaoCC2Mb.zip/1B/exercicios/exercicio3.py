"""
1) Crie uma função que receba um inteiro por parametro e e devolva o fatorial deste 
numero

2)Crie as funções Arranjo e Combinação que utilizam a função fatorial da questao 
anterior para realizar seus calculos

>>Os resultados devem ser retornados pelas funções
"""

def fatorial(n): 
  if(n > 1):
    return n * fatorial(n-1)
  else:
    return 1

print(f"O fatorial de 5 é: {fatorial(5)}")

def arranjo(n, p):
  return fatorial(n) / fatorial(n-p)

def combinacao(n, p):
  return fatorial(n) / fatorial(p) * fatorial(n-p)

print(f"O arranjo de 5 é: {fatorial(5)}")
print(f"O arranjo de 5, 2 a 2 é: {arranjo(5, 2)}")
print(f"A combinação de 5, 2 a 2 é: {combinacao(5, 2)}")

