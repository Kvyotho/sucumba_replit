"""
palavra = "Eu gosto de café"

if "café" in palavra:
  print("Tem sim!")
"""

nomes = ["Jorge, ""Antonio", "Fernanda", "Jose", "Joao", "Wagner", "Maria"]

nomes_com_j = []

for nome in nomes:
  if "J" in nome:
    nomes_com_j.append(nome)

print("Nomes com J: ", nomes_com_j)

#USANDO LIST COMPREHENSION
nomes_com_j = [nome for nome in nomes if "J" in nome]
print("Nomes com J: ", nomes_com_j)