x, y, z = "Carlos", "Andre", "Joao"

a = b = c = "Wagner"

print(x)
print(y)
print(z)
print(a)
print(b)
print(c)

alunos = ["Carlos", "Andre", "Joao"]

x, y, z = alunos

print(x)
print(y)
print(z)