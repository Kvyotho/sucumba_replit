"""
Data Types
- Text: str
- Numerics: int, float, complex
- Sequences: list, tuple, range
- Mapping: dict
- Set: set, frozenset
- boolean: bool (True, false)
- Binary: bytes, bytearray, memoryview
- none: NonoType
"""

x = ["Wagner", "Carlos", "Jose"]

print(type(x))  #para descobrir o datatype da variavel

