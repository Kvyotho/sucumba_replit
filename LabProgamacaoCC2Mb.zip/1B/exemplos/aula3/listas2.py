
nomes = ["Antonio", "Fernanda", "Jose", "Joao", "Wagner", "Maria"]

print("###ITERANDO COM FOR###")
for nome in nomes:
  print(nome)


print(list(range(6))) 
print("###ITERANDO PELO INDICE###")
for i in range(len(nomes)):
  print(nomes[i])

print("###ITERANDO COM WHILE###")
i = 0 
while i < len(nomes):
  print(nomes[i])
  i += 1

#perfomance for/while >> indice, porque indice precisa criar um vetor

print("###USANDO LIST COMPREHENSION###")
[print(nome) for nome in nomes]

#criar conta no stack overflow xdd




