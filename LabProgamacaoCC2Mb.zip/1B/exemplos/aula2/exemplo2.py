def func():
  global x
  x = "Matheus"

func()

print("Meu nome é: ", x)
#--------------------------
x = "Wagner"

def func():
  global x
  x = Carlos

func()

print("Meu nome é: ", x)