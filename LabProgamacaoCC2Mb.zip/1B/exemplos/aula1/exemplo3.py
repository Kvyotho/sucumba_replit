x = 10
y = 10.5

a = '25'

b = int(a) * x
c = a * x

print(b)
print(c)

d = a + str(x)
print(d)