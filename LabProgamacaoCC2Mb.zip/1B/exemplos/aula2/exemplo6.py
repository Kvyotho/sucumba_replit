# Boolean (True, False)

print(10 > 9)

"""
Operadores
 - Aritméticos (+, -, *, /, %, **, //)
 - Atribuição (Ajuda a simplficar o código)
 - Comparação (==, !=, >, <, >=, <=)
 - Lógicos (and, or, not)
 - Membro (in, not in)

 % = resto
 ** = exponencial
 // = divisão inteira
"""

a = 7
b = 3

c = a % b

c = a ** b

c = a // b
print(c)


x = 3

x += 3 # x = x + 3
x -=3 # x = x - 3 
x *= 3 # x = x * 3
x /= 3 # x = x / 3
#Python não tem x++

print(x)

"""
Comparações
 == -> Igual a
 != -> Diferente de
 >, <, >=, <=
"""

"""
Lógicos
 and, or, not
"""

a = 20 > 5 and 5 < 8
print(a)

"""
Membros (util ???)
"""
alunos = ["Carlos", "Andre", "Joao"]

print("Carlos" in alunos)
print("Wagner" not in alunos)




