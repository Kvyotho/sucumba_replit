x = 10
y = 'Matheus'
z = 25.5

print(type(x))
print(type(y))
print(type(z))

'''
Nomes de variáveis
- Começam sempre com letras ou _
- Só podem conter caracteres alfanuméricos (a-Z, 0-9, _)
- Não pode começar com numéro
- Não pode usar palavras reservadas do Python (Python Keywords)
- Não pode conter operadores e espaços em branco
'''

