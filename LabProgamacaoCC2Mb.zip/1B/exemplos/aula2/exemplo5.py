#strings

x = 'assim'
y = "assim"

if x == y:
  print("Iguais")

#slicing

x = "Wagner Perin"

print(x[7:])
print(x[0:7])

print(x[-5:])

print(x.upper())
print(x.lower())

x = "   Wagner Perin     "

print(x)
print(x.strip())

x = "Vagner Perin"
x.replace("V", "W")

nomes = "Wagner Carlos Andre"
alunos = nomes.split(" ")

print(alunos)

nome = "Wagner"
sobrenome = "Perin"
nome_completo = nome + " " + sobrenome  #concatenar

print(nome_completo)

#Strings formatadas
idade = 30
nome = "Wagner Perin"

saida = f"Meu nome é {nome} e tenho {idade} anos."

print(saida)

preco = 50.50
produto = "Vinho"

saida = f"O {produto} custa R$ {preco:.2f}"
print(saida)

#Escapes
frase = "E o Nicolas disse \n 'Olá Professor!'"

print(frase)

#Estudar as funções de strings xdd, W3Schools, possivelmente vai cair na prova