### 1) ###

def criar_matriz(linhas, colunas, valor):
  mat = []
  for x in range(linhas):
    row = []
    for y in range(colunas):
      row.append(valor)
    mat.append(row)

  return mat

mat = criar_matriz(3,4,0)
print(mat)


### 2) ###

def e_matriz_identidade(matriz):
  i = 0
  j = 0

  #Verifica se a matriz é quadrada
  if len(matriz) != len(matriz[0]): 
    return False

  # Percorre os items da matriz e verifica se todos da diagonais são "1" 
  # e se todos os outros são "0"
  for i in range(len(matriz)):  
    for j in range(len(matriz)):
      if i == j and matriz[i][j] != 1:
        return False
      elif i != j and matriz[i][j] != 0:
        return False

  return True


mat1 = [
  [1,2,3],
  [4,5,6],
  [7,8,9]
]

mat2 = [
  [1,0,0],
  [0,1,0],
  [0,0,1]
]

print(e_matriz_identidade(mat1))
print(e_matriz_identidade(mat2))

### 3) ###

def extrair_diagonal(matriz):

  extracdiag = []

  for i in range(len(matriz)):  
    for j in range(len(matriz)):
      if i == j:
        extracdiag.append(matriz[i][j])

  return extracdiag

mat = [
  [1,2,3],
  [4,5,6],
  [7,8,9]
]

lista_extracdiag = extrair_diagonal(mat)

print(lista_extracdiag)

### 4) ###

def calcular_traco(matriz):

  soma = 0

  for i in range(len(matriz)):
    soma += matriz[i][i]

  return soma


print(calcular_traco(mat))

### 5) ### 

def e_matriz_nula(matriz):
  for i in range(len(matriz)):
    for j in range(len(matriz[i])):
      if matriz[i][j] != 0:
        return False
  
  return True

mat3 = [
  [0,0,0],
  [0,0,0],
  [0,0,0]
]

print(e_matriz_nula(mat))
print(e_matriz_nula(mat3))

### 6 ###

def multiplicar_escalar(matriz, escalar):

  matriz_me = []
  nova_linha = []
      
  for linha in matriz:
    nova_linha = [elemento * escalar for elemento in linha]
    matriz_me.append(nova_linha)

  return matriz_me

print(multiplicar_escalar([[1, 2],[3, 4]], 3))


### 7 ###

def soma_linhas(matriz):

  matriz_sl = []

  for linha in matriz:
    soma = sum(linha)
    matriz_sl.append(soma)

  return matriz_sl

def soma_colunas(matriz):
  
  
  colunas = len(matriz[0])
  matriz_sc = [
    sum(matriz[i][j] for i in range(len(matriz)))
    for j in range(colunas)
  ]
  return matriz_sc

matriz = [
  [1,2,3],
  [4,5,6]
]

print(soma_linhas(matriz))
print(soma_colunas(matriz))

### 8 ###

def e_matriz_esparsa(matriz):

  total = len(matriz) * len(matriz[0])
  nzeros = 0

  for linha in matriz:
    for elemento in linha:
        if elemento == 0:
            nzeros += 1

  media = nzeros / total

  return media > 0.5

matriz = [
  [1,2,3],
  [4,5,6],
  [7,8,9]
]

matrizzeros = [
  [0,0,1],
  [0,0,0],
  [0,0,0]
]
print(e_matriz_esparsa(matriz))
print(e_matriz_esparsa(matrizzeros))

### 9 ### 

def rotacionar_matriz_90(matriz):

  matriz_rot = list(zip(*matriz))
  matriz_rot_inv = [list(linha)[::-1] for linha in (matriz_rot)]

  return matriz_rot_inv


print(rotacionar_matriz_90(matriz))

### 10 ###

def e_matriz_simetrica(matriz):

  simetria1 = list(zip(*matriz))
  simetria2 = [list(linha) for linha in (simetria1)]
  return matriz == simetria2

matriz = [
  [1,2,3],
  [4,5,6],
  [7,8,9]
]

matrizsim = [
  [1,2,3],
  [2,4,5],
  [3,5,6]
]

print(e_matriz_simetrica(matriz))
print(e_matriz_simetrica(matrizsim))
  