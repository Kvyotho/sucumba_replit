"""
1) Crie uma função chamada "divisao_segura" que receba dois número como argumentos, calcule e retorne a divisão deles. Caso o divisor seja zero, emita uma mensagem de erro

2) Escreva uma função chamada "calculo_salario" que aceite o salario base de um funcionario, um bonus opcional(com valor padrão zero), e um numero variável de deduções. A função deve calcular e retornar o salário final de um funcionário
"""

def divisao_segura(a, b):
  if b!= 0:
    return a / b
  else:
    raise Exception("Não é possível dividir por zero!")

try:
  print(divisao_segura(10, 0))
except Exception as e:
  print("Aconteceu um erro " + repr(e))
  
print(divisao_segura(10, 5))

def calculo_salario(v1, v2, v3):
  salario = 0
  salario = v1 + v2 - v3
  return salario
  
  