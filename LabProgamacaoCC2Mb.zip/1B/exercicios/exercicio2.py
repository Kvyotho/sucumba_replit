"""
def imprime_imc(imc):
  if imc > 25:
    print("Você está acima do peso recomendado")
  elif imc > 18.5 and imc < 25:
    print("Você está no IMC ideal")
  else:
    print("Você está abaixo do peso recomendado")
"""

def calcula_imc(peso,altura):
  imc = peso / (altura * altura)
  return imc
  
def verifica_imc(imc):
  if imc < 18.5:
    print("Abaixo do peso")
  elif imc <= 25:
    print("Peso normal")
  else:
    print("Acima do peso")

meu_imc = calcula_imc(92, 1.82)
print("Meu IMC é: ", str(meu_imc))

verifica_imc(meu_imc)
