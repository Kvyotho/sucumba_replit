#escopo de variáveis
#Global

x = "Matheus"

def func():
  print("Meu nom é: " , x)


def func2():
  print("Meu nome é: ", x)

func()
func2()

