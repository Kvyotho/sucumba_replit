"""
3 aspas = comentario
com 
multiplas
linhas
"""

print("Ola mundo!")

print("Ola", "Wagner", "Perin") # imprime o nome

preco = 100
print("O preço do produto é: ", preco)
#string formatada
print(f"O preço do produto é: R$ {preco: .2f}")