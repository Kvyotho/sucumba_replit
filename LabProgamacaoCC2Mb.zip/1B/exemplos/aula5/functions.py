"""
Funções - São blocos de instruções que podem ser executados quando chamados.
-Podem receber dados necessários para processamento (parametros/argumentos)
-Podem devolver valores resultantes de sua operação
"""

def minha_func():
  print("Você chamou sua função!!!!")

minha_func()

def imprime_mensagem(nome):
  print(f"Olá {nome}, tudo bem?")

imprime_mensagem("Wagner")
imprime_mensagem("Nathan")

def imprime_nome_completo(nome, sobrenome="Perin"):
  print(f"Nome_completo: {nome} {sobrenome}")

imprime_nome_completo("Gael")
imprime_nome_completo("Wagner", "Perin")

#tuplas como argumentos
def minha_funcao(*args):
  print("Argumento 2: " + args[4])
  
try:
  minha_funcao("Arg 1", "Arg 2", "Arg 3", "Arg 4")
except IndexError:
  print("Ocorreu um erro, mas vida que segue")

print("Será que esse print aparece?")