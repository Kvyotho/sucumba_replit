"""
Listas em Python
- São ordenadas
- São indexados
- São modificáveis
- Permitem Duplicaas
"""

nomes = ["Wagner", "Antonio", "Jose", "Joao", "Wagner"]

print(nomes)
print(nomes[2]) #starts with zero, so [0,1,2,3]
nomes[2] = "Maria"
print(nomes[2])

dados = ["Nicolas", 28, 1.86, True]
print(dados)

print(len(nomes))

print(type(nomes))
print(type(nomes[2]))

print(nomes[2:])

print(nomes[2:4])

print(nomes[-1])

#in operator

if "Maria" in nomes:
  print("Eu conheço a Maria!")
else:
  print("Eu não conheço a Maria")

print(nomes.__contains__("Maria")) #ssdd do if, porem mais complicado

nomes = ["Wagner", "Antonio", "Jose", "Joao", "Wagner"]

#nomes[2:4] = ["Maria", "Clara", "Fernanda"]

#incluindo elementos
nomes.append("Maria")

nomes.insert(2, "Fernanda")

#removendo elementos
nomes.remove("Wagner")

print(nomes)
removido = nomes.pop()
print(nomes)
print(removido)
removido = nomes.pop(2)
print(nomes)
print(removido)

del nomes[1]
print(nomes)

#del nomes -> lista é evaporada
#nomes.clear() ->lista continua existindo na memoria, porem vazia

